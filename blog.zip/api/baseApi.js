// export const BASE_URL = "http://localhost:3000/api";
export const BASE_URL = "https://ldd-backend.vercel.app/api";
